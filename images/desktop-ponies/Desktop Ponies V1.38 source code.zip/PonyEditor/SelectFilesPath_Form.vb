﻿Imports System.Windows.Forms

Public Class SelectFilesPath_Form

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        If Not My.Computer.FileSystem.DirectoryExists(My.Forms.Main.screen_saver_path) Then
            MsgBox("Selected path does not exist.")
            Exit Sub
        End If

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub Browse_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Browse_Button.Click

        If FolderBrowserDialog.ShowDialog() = DialogResult.OK Then
            My.Forms.Main.screen_saver_path = FolderBrowserDialog.SelectedPath
            Path_Textbox.Text = My.Forms.Main.screen_saver_path
        End If

    End Sub
End Class
