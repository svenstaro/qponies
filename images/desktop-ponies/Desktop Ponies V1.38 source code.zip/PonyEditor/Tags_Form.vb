﻿Public Class Tags_Form

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.Close()
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        My.Forms.Pony_Editor.Preview_Pony.Tags.Clear()

        For Each Tag As String In PonyFilter_Box.CheckedItems
            My.Forms.Pony_Editor.Preview_Pony.Tags.Add(Tag)
        Next

        Me.Close()

    End Sub

    Private Sub Tags_Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        PonyFilter_Box.Items.Clear()

        Me.Text = "Tags for " & My.Forms.Pony_Editor.Preview_Pony.Name

        For Each category In My.Forms.Main.PonyFilter_Box.Items
            If category = "Not Tagged" Then Continue For
            PonyFilter_Box.Items.Add(category)
        Next

        For Each Tag As String In My.Forms.Pony_Editor.Preview_Pony.Tags
            For Each category In PonyFilter_Box.Items
                If LCase(Tag) = LCase(category) Then
                    PonyFilter_Box.SetItemChecked(PonyFilter_Box.Items.IndexOf(category), True)
                    Exit For
                End If
            Next
        Next


    End Sub

End Class