﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pony_Editor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Pony_Preview_Panel = New System.Windows.Forms.Panel()
        Me.label35 = New System.Windows.Forms.Label()
        Me.Pony_Selection_View = New System.Windows.Forms.ListView()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.new_pony_button = New System.Windows.Forms.Button()
        Me.Pony_Name_Box = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Pony_Behaviors_Grid = New System.Windows.Forms.DataGridView()
        Me.Activate_Behavior = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Behavior_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Original_Behavior_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Probability = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Max_Duration = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Min_Duration = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Speed = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Right_Image = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Left_Image = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Movement = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Start_Speech = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.End_Speech = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Follow = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Linked_Behavior = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Link_Number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Skip_on_Random = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Pony_Speech_Grid = New System.Windows.Forms.DataGridView()
        Me.Speech_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Original_Speech_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Speech_Text = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sound_File = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Skip = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Pony_Interaction_Grid = New System.Windows.Forms.DataGridView()
        Me.Interaction_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Original_Interaction_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Interaction_Probability = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Proximity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Targets = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Random_All = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Behaviors = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Delay = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Slot0Label = New System.Windows.Forms.Label()
        Me.Slot1Label = New System.Windows.Forms.Label()
        Me.Slot3Label = New System.Windows.Forms.Label()
        Me.Pony_Effects_Grid = New System.Windows.Forms.DataGridView()
        Me.Effect_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Original_Effect_Name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Effect_Behavior = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Effect_Right_Image = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Effect_Left_Image = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Duration = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Repeat_Delay = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Location_Right = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Centering_Right = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Location_Left = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Centering_Left = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Follow_Pony = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.current_behavior_label = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.current_behavior_timeleft_label = New System.Windows.Forms.Label()
        Me.Slot2Label = New System.Windows.Forms.Label()
        Me.New_Behavior_Button = New System.Windows.Forms.Button()
        Me.New_Speech_Button = New System.Windows.Forms.Button()
        Me.New_Effect_Button = New System.Windows.Forms.Button()
        Me.New_Interaction_Button = New System.Windows.Forms.Button()
        Me.Swap1_0 = New System.Windows.Forms.Button()
        Me.Swap2_0 = New System.Windows.Forms.Button()
        Me.Swap3_0 = New System.Windows.Forms.Button()
        Me.Swap0_1 = New System.Windows.Forms.Button()
        Me.Pause_Pony_Button = New System.Windows.Forms.Button()
        Me.OpenPictureDialog = New System.Windows.Forms.OpenFileDialog()
        Me.Save_Button = New System.Windows.Forms.Button()
        Me.Edit_Tags_Button = New System.Windows.Forms.Button()
        Me.Set_Image_Centers_Button = New System.Windows.Forms.Button()
        Me.Panel2.SuspendLayout()
        CType(Me.Pony_Behaviors_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pony_Speech_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pony_Interaction_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pony_Effects_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pony_Preview_Panel
        '
        Me.Pony_Preview_Panel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pony_Preview_Panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pony_Preview_Panel.Location = New System.Drawing.Point(217, 18)
        Me.Pony_Preview_Panel.Name = "Pony_Preview_Panel"
        Me.Pony_Preview_Panel.Size = New System.Drawing.Size(692, 221)
        Me.Pony_Preview_Panel.TabIndex = 0
        '
        'label35
        '
        Me.label35.AutoSize = True
        Me.label35.Location = New System.Drawing.Point(214, 9)
        Me.label35.Name = "label35"
        Me.label35.Size = New System.Drawing.Size(72, 13)
        Me.label35.TabIndex = 1
        Me.label35.Text = "Pony Preview"
        '
        'Pony_Selection_View
        '
        Me.Pony_Selection_View.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.Pony_Selection_View.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Pony_Selection_View.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.Pony_Selection_View.HideSelection = False
        Me.Pony_Selection_View.LabelWrap = False
        Me.Pony_Selection_View.Location = New System.Drawing.Point(17, 22)
        Me.Pony_Selection_View.MultiSelect = False
        Me.Pony_Selection_View.Name = "Pony_Selection_View"
        Me.Pony_Selection_View.ShowGroups = False
        Me.Pony_Selection_View.Size = New System.Drawing.Size(117, 204)
        Me.Pony_Selection_View.TabIndex = 2
        Me.Pony_Selection_View.UseCompatibleStateImageBehavior = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(14, 6)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 13)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "Select Pony:"
        '
        'new_pony_button
        '
        Me.new_pony_button.Location = New System.Drawing.Point(42, 232)
        Me.new_pony_button.Name = "new_pony_button"
        Me.new_pony_button.Size = New System.Drawing.Size(75, 21)
        Me.new_pony_button.TabIndex = 4
        Me.new_pony_button.Text = "Create NEW Pony"
        Me.new_pony_button.UseVisualStyleBackColor = True
        '
        'Pony_Name_Box
        '
        Me.Pony_Name_Box.Location = New System.Drawing.Point(264, 254)
        Me.Pony_Name_Box.Name = "Pony_Name_Box"
        Me.Pony_Name_Box.Size = New System.Drawing.Size(98, 20)
        Me.Pony_Name_Box.TabIndex = 5
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.new_pony_button)
        Me.Panel2.Controls.Add(Me.Pony_Selection_View)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Location = New System.Drawing.Point(27, 12)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(152, 262)
        Me.Panel2.TabIndex = 6
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(220, 257)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(38, 13)
        Me.Label25.TabIndex = 7
        Me.Label25.Text = "Name:"
        '
        'Pony_Behaviors_Grid
        '
        Me.Pony_Behaviors_Grid.AllowUserToAddRows = False
        Me.Pony_Behaviors_Grid.AllowUserToResizeRows = False
        Me.Pony_Behaviors_Grid.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pony_Behaviors_Grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Pony_Behaviors_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Activate_Behavior, Me.Behavior_Name, Me.Original_Behavior_Name, Me.Probability, Me.Max_Duration, Me.Min_Duration, Me.Speed, Me.Right_Image, Me.Left_Image, Me.Movement, Me.Start_Speech, Me.End_Speech, Me.Follow, Me.Linked_Behavior, Me.Link_Number, Me.Skip_on_Random})
        Me.Pony_Behaviors_Grid.Location = New System.Drawing.Point(12, 315)
        Me.Pony_Behaviors_Grid.MultiSelect = False
        Me.Pony_Behaviors_Grid.Name = "Pony_Behaviors_Grid"
        Me.Pony_Behaviors_Grid.Size = New System.Drawing.Size(915, 211)
        Me.Pony_Behaviors_Grid.TabIndex = 8
        '
        'Activate_Behavior
        '
        Me.Activate_Behavior.HeaderText = "Activate"
        Me.Activate_Behavior.Name = "Activate_Behavior"
        Me.Activate_Behavior.Width = 52
        '
        'Behavior_Name
        '
        Me.Behavior_Name.HeaderText = "Name"
        Me.Behavior_Name.MaxInputLength = 255
        Me.Behavior_Name.Name = "Behavior_Name"
        Me.Behavior_Name.Width = 60
        '
        'Original_Behavior_Name
        '
        Me.Original_Behavior_Name.HeaderText = "Original Name"
        Me.Original_Behavior_Name.Name = "Original_Behavior_Name"
        Me.Original_Behavior_Name.Visible = False
        Me.Original_Behavior_Name.Width = 98
        '
        'Probability
        '
        Me.Probability.HeaderText = "Chance"
        Me.Probability.Name = "Probability"
        Me.Probability.Width = 69
        '
        'Max_Duration
        '
        Me.Max_Duration.HeaderText = "Max Duration"
        Me.Max_Duration.Name = "Max_Duration"
        Me.Max_Duration.Width = 88
        '
        'Min_Duration
        '
        Me.Min_Duration.HeaderText = "Min Duration"
        Me.Min_Duration.Name = "Min_Duration"
        Me.Min_Duration.Width = 85
        '
        'Speed
        '
        Me.Speed.HeaderText = "Speed"
        Me.Speed.Name = "Speed"
        Me.Speed.Width = 63
        '
        'Right_Image
        '
        Me.Right_Image.HeaderText = "Right Image"
        Me.Right_Image.Name = "Right_Image"
        Me.Right_Image.Width = 63
        '
        'Left_Image
        '
        Me.Left_Image.HeaderText = "Left Image"
        Me.Left_Image.Name = "Left_Image"
        Me.Left_Image.Width = 57
        '
        'Movement
        '
        Me.Movement.HeaderText = "Movement Allowed"
        Me.Movement.Items.AddRange(New Object() {"None", "Horizontal Only", "Vertical Only", "Horizontal Vertical", "Diagonal Only", "Diagonal/horizontal", "Diagonal/Vertical", "All", "MouseOver", "Sleep", "Dragged"})
        Me.Movement.Name = "Movement"
        Me.Movement.Width = 93
        '
        'Start_Speech
        '
        Me.Start_Speech.HeaderText = "Starting Speech"
        Me.Start_Speech.Name = "Start_Speech"
        Me.Start_Speech.Width = 80
        '
        'End_Speech
        '
        Me.End_Speech.HeaderText = "Ending Speech"
        Me.End_Speech.Name = "End_Speech"
        Me.End_Speech.Width = 78
        '
        'Follow
        '
        Me.Follow.HeaderText = "Follows/Goto:"
        Me.Follow.Name = "Follow"
        Me.Follow.Width = 79
        '
        'Linked_Behavior
        '
        Me.Linked_Behavior.HeaderText = "Link to:"
        Me.Linked_Behavior.Name = "Linked_Behavior"
        Me.Linked_Behavior.Width = 33
        '
        'Link_Number
        '
        Me.Link_Number.HeaderText = "Link Order"
        Me.Link_Number.Name = "Link_Number"
        Me.Link_Number.ReadOnly = True
        Me.Link_Number.Width = 75
        '
        'Skip_on_Random
        '
        Me.Skip_on_Random.HeaderText = "Don't run randomly"
        Me.Skip_on_Random.Name = "Skip_on_Random"
        Me.Skip_on_Random.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Skip_on_Random.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Skip_on_Random.Width = 110
        '
        'Pony_Speech_Grid
        '
        Me.Pony_Speech_Grid.AllowUserToAddRows = False
        Me.Pony_Speech_Grid.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Pony_Speech_Grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Pony_Speech_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Speech_Name, Me.Original_Speech_Name, Me.Speech_Text, Me.Sound_File, Me.Skip})
        Me.Pony_Speech_Grid.Location = New System.Drawing.Point(7, 567)
        Me.Pony_Speech_Grid.MultiSelect = False
        Me.Pony_Speech_Grid.Name = "Pony_Speech_Grid"
        Me.Pony_Speech_Grid.Size = New System.Drawing.Size(307, 150)
        Me.Pony_Speech_Grid.TabIndex = 9
        '
        'Speech_Name
        '
        Me.Speech_Name.HeaderText = "Name"
        Me.Speech_Name.Name = "Speech_Name"
        Me.Speech_Name.Width = 60
        '
        'Original_Speech_Name
        '
        Me.Original_Speech_Name.HeaderText = "Original Name"
        Me.Original_Speech_Name.Name = "Original_Speech_Name"
        Me.Original_Speech_Name.Visible = False
        Me.Original_Speech_Name.Width = 98
        '
        'Speech_Text
        '
        Me.Speech_Text.HeaderText = "Text"
        Me.Speech_Text.Name = "Speech_Text"
        Me.Speech_Text.Width = 53
        '
        'Sound_File
        '
        Me.Sound_File.HeaderText = "Sound File"
        Me.Sound_File.Name = "Sound_File"
        Me.Sound_File.Width = 63
        '
        'Skip
        '
        Me.Skip.HeaderText = "Use Randomly"
        Me.Skip.Name = "Skip"
        Me.Skip.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Skip.Width = 82
        '
        'Pony_Interaction_Grid
        '
        Me.Pony_Interaction_Grid.AllowUserToAddRows = False
        Me.Pony_Interaction_Grid.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pony_Interaction_Grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Pony_Interaction_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Interaction_Name, Me.Original_Interaction_Name, Me.Interaction_Probability, Me.Proximity, Me.Targets, Me.Random_All, Me.Behaviors, Me.Delay})
        Me.Pony_Interaction_Grid.Location = New System.Drawing.Point(634, 567)
        Me.Pony_Interaction_Grid.MultiSelect = False
        Me.Pony_Interaction_Grid.Name = "Pony_Interaction_Grid"
        Me.Pony_Interaction_Grid.Size = New System.Drawing.Size(302, 150)
        Me.Pony_Interaction_Grid.TabIndex = 10
        '
        'Interaction_Name
        '
        Me.Interaction_Name.HeaderText = "Name"
        Me.Interaction_Name.Name = "Interaction_Name"
        Me.Interaction_Name.Width = 60
        '
        'Original_Interaction_Name
        '
        Me.Original_Interaction_Name.HeaderText = "Original Name"
        Me.Original_Interaction_Name.Name = "Original_Interaction_Name"
        Me.Original_Interaction_Name.Visible = False
        Me.Original_Interaction_Name.Width = 98
        '
        'Interaction_Probability
        '
        Me.Interaction_Probability.HeaderText = "Chance"
        Me.Interaction_Probability.Name = "Interaction_Probability"
        Me.Interaction_Probability.Width = 69
        '
        'Proximity
        '
        Me.Proximity.HeaderText = "Activation Proximity"
        Me.Proximity.Name = "Proximity"
        Me.Proximity.Width = 123
        '
        'Targets
        '
        Me.Targets.HeaderText = "Targets"
        Me.Targets.Name = "Targets"
        Me.Targets.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Targets.Width = 49
        '
        'Random_All
        '
        Me.Random_All.HeaderText = "Interact with:"
        Me.Random_All.Items.AddRange(New Object() {"All", "Random"})
        Me.Random_All.Name = "Random_All"
        Me.Random_All.Width = 74
        '
        'Behaviors
        '
        Me.Behaviors.HeaderText = "Behaviors"
        Me.Behaviors.Name = "Behaviors"
        Me.Behaviors.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Behaviors.Width = 60
        '
        'Delay
        '
        Me.Delay.HeaderText = "Reactivation Delay"
        Me.Delay.Name = "Delay"
        Me.Delay.Width = 122
        '
        'Slot0Label
        '
        Me.Slot0Label.AutoSize = True
        Me.Slot0Label.Location = New System.Drawing.Point(160, 299)
        Me.Slot0Label.Name = "Slot0Label"
        Me.Slot0Label.Size = New System.Drawing.Size(57, 13)
        Me.Slot0Label.TabIndex = 11
        Me.Slot0Label.Text = "Behaviors:"
        '
        'Slot1Label
        '
        Me.Slot1Label.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Slot1Label.AutoSize = True
        Me.Slot1Label.Location = New System.Drawing.Point(24, 551)
        Me.Slot1Label.Name = "Slot1Label"
        Me.Slot1Label.Size = New System.Drawing.Size(47, 13)
        Me.Slot1Label.TabIndex = 12
        Me.Slot1Label.Text = "Speech:"
        '
        'Slot3Label
        '
        Me.Slot3Label.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Slot3Label.AutoSize = True
        Me.Slot3Label.Location = New System.Drawing.Point(647, 551)
        Me.Slot3Label.Name = "Slot3Label"
        Me.Slot3Label.Size = New System.Drawing.Size(65, 13)
        Me.Slot3Label.TabIndex = 13
        Me.Slot3Label.Text = "Interactions:"
        '
        'Pony_Effects_Grid
        '
        Me.Pony_Effects_Grid.AllowUserToAddRows = False
        Me.Pony_Effects_Grid.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Pony_Effects_Grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Pony_Effects_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Effect_Name, Me.Original_Effect_Name, Me.Effect_Behavior, Me.Effect_Right_Image, Me.Effect_Left_Image, Me.Duration, Me.Repeat_Delay, Me.Location_Right, Me.Centering_Right, Me.Location_Left, Me.Centering_Left, Me.Follow_Pony})
        Me.Pony_Effects_Grid.Location = New System.Drawing.Point(329, 567)
        Me.Pony_Effects_Grid.MultiSelect = False
        Me.Pony_Effects_Grid.Name = "Pony_Effects_Grid"
        Me.Pony_Effects_Grid.Size = New System.Drawing.Size(291, 150)
        Me.Pony_Effects_Grid.TabIndex = 14
        '
        'Effect_Name
        '
        Me.Effect_Name.HeaderText = "Name"
        Me.Effect_Name.Name = "Effect_Name"
        Me.Effect_Name.Width = 60
        '
        'Original_Effect_Name
        '
        Me.Original_Effect_Name.HeaderText = "Original_Name"
        Me.Original_Effect_Name.Name = "Original_Effect_Name"
        Me.Original_Effect_Name.Visible = False
        Me.Original_Effect_Name.Width = 101
        '
        'Effect_Behavior
        '
        Me.Effect_Behavior.HeaderText = "Behavior"
        Me.Effect_Behavior.Name = "Effect_Behavior"
        Me.Effect_Behavior.Width = 55
        '
        'Effect_Right_Image
        '
        Me.Effect_Right_Image.HeaderText = "Right Image"
        Me.Effect_Right_Image.Name = "Effect_Right_Image"
        Me.Effect_Right_Image.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Effect_Right_Image.Width = 70
        '
        'Effect_Left_Image
        '
        Me.Effect_Left_Image.HeaderText = "Left Image"
        Me.Effect_Left_Image.Name = "Effect_Left_Image"
        Me.Effect_Left_Image.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Effect_Left_Image.Width = 63
        '
        'Duration
        '
        Me.Duration.HeaderText = "Duration"
        Me.Duration.Name = "Duration"
        Me.Duration.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Duration.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Duration.Width = 53
        '
        'Repeat_Delay
        '
        Me.Repeat_Delay.HeaderText = "Repeat Delay"
        Me.Repeat_Delay.Name = "Repeat_Delay"
        Me.Repeat_Delay.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Repeat_Delay.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Repeat_Delay.Width = 78
        '
        'Location_Right
        '
        Me.Location_Right.HeaderText = "Location Heading Right"
        Me.Location_Right.Items.AddRange(New Object() {"Top", "Bottom", "Left", "Right", "Bottom Right", "Bottom Left", "Top Right", "Top Left", "Center", "Any", "Any-Not Center"})
        Me.Location_Right.Name = "Location_Right"
        Me.Location_Right.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Location_Right.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Location_Right.Width = 144
        '
        'Centering_Right
        '
        Me.Centering_Right.HeaderText = "Centering Right"
        Me.Centering_Right.Items.AddRange(New Object() {"Top", "Bottom", "Left", "Right", "Bottom Right", "Bottom Left", "Top Right", "Top Left", "Center", "Any", "Any-Not Center"})
        Me.Centering_Right.Name = "Centering_Right"
        Me.Centering_Right.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Centering_Right.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Centering_Right.Width = 105
        '
        'Location_Left
        '
        Me.Location_Left.HeaderText = "Location heading Left"
        Me.Location_Left.Items.AddRange(New Object() {"Top", "Bottom", "Left", "Right", "Bottom Right", "Bottom Left", "Top Right", "Top Left", "Center", "Any", "Any-Not Center"})
        Me.Location_Left.Name = "Location_Left"
        Me.Location_Left.Width = 116
        '
        'Centering_Left
        '
        Me.Centering_Left.HeaderText = "Centering Left"
        Me.Centering_Left.Items.AddRange(New Object() {"Top", "Bottom", "Left", "Right", "Bottom Right", "Bottom Left", "Top Right", "Top Left", "Center", "Any", "Any-Not Center"})
        Me.Centering_Left.Name = "Centering_Left"
        Me.Centering_Left.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Centering_Left.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Centering_Left.Width = 98
        '
        'Follow_Pony
        '
        Me.Follow_Pony.HeaderText = "Follow Pony?"
        Me.Follow_Pony.Name = "Follow_Pony"
        Me.Follow_Pony.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Follow_Pony.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Follow_Pony.Width = 95
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(748, 245)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Current Behavior:"
        '
        'current_behavior_label
        '
        Me.current_behavior_label.AutoSize = True
        Me.current_behavior_label.Location = New System.Drawing.Point(843, 245)
        Me.current_behavior_label.Name = "current_behavior_label"
        Me.current_behavior_label.Size = New System.Drawing.Size(27, 13)
        Me.current_behavior_label.TabIndex = 16
        Me.current_behavior_label.Text = "N/A"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(783, 263)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Time Left:"
        '
        'current_behavior_timeleft_label
        '
        Me.current_behavior_timeleft_label.AutoSize = True
        Me.current_behavior_timeleft_label.Location = New System.Drawing.Point(843, 263)
        Me.current_behavior_timeleft_label.Name = "current_behavior_timeleft_label"
        Me.current_behavior_timeleft_label.Size = New System.Drawing.Size(27, 13)
        Me.current_behavior_timeleft_label.TabIndex = 18
        Me.current_behavior_timeleft_label.Text = "N/A"
        '
        'Slot2Label
        '
        Me.Slot2Label.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Slot2Label.AutoSize = True
        Me.Slot2Label.Location = New System.Drawing.Point(356, 551)
        Me.Slot2Label.Name = "Slot2Label"
        Me.Slot2Label.Size = New System.Drawing.Size(43, 13)
        Me.Slot2Label.TabIndex = 19
        Me.Slot2Label.Text = "Effects:"
        '
        'New_Behavior_Button
        '
        Me.New_Behavior_Button.Location = New System.Drawing.Point(830, 286)
        Me.New_Behavior_Button.Name = "New_Behavior_Button"
        Me.New_Behavior_Button.Size = New System.Drawing.Size(93, 23)
        Me.New_Behavior_Button.TabIndex = 20
        Me.New_Behavior_Button.Text = "New Behavior"
        Me.New_Behavior_Button.UseVisualStyleBackColor = True
        '
        'New_Speech_Button
        '
        Me.New_Speech_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.New_Speech_Button.Location = New System.Drawing.Point(196, 541)
        Me.New_Speech_Button.Name = "New_Speech_Button"
        Me.New_Speech_Button.Size = New System.Drawing.Size(90, 23)
        Me.New_Speech_Button.TabIndex = 21
        Me.New_Speech_Button.Text = "New Speech"
        Me.New_Speech_Button.UseVisualStyleBackColor = True
        '
        'New_Effect_Button
        '
        Me.New_Effect_Button.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.New_Effect_Button.Location = New System.Drawing.Point(508, 541)
        Me.New_Effect_Button.Name = "New_Effect_Button"
        Me.New_Effect_Button.Size = New System.Drawing.Size(96, 23)
        Me.New_Effect_Button.TabIndex = 22
        Me.New_Effect_Button.Text = "New Effect"
        Me.New_Effect_Button.UseVisualStyleBackColor = True
        '
        'New_Interaction_Button
        '
        Me.New_Interaction_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.New_Interaction_Button.Location = New System.Drawing.Point(817, 541)
        Me.New_Interaction_Button.Name = "New_Interaction_Button"
        Me.New_Interaction_Button.Size = New System.Drawing.Size(92, 23)
        Me.New_Interaction_Button.TabIndex = 23
        Me.New_Interaction_Button.Text = "New Interaction"
        Me.New_Interaction_Button.UseVisualStyleBackColor = True
        '
        'Swap1_0
        '
        Me.Swap1_0.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Swap1_0.BackColor = System.Drawing.Color.GreenYellow
        Me.Swap1_0.Location = New System.Drawing.Point(106, 541)
        Me.Swap1_0.Name = "Swap1_0"
        Me.Swap1_0.Size = New System.Drawing.Size(73, 23)
        Me.Swap1_0.TabIndex = 24
        Me.Swap1_0.Text = "Swap"
        Me.Swap1_0.UseVisualStyleBackColor = False
        '
        'Swap2_0
        '
        Me.Swap2_0.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Swap2_0.BackColor = System.Drawing.Color.GreenYellow
        Me.Swap2_0.Location = New System.Drawing.Point(417, 541)
        Me.Swap2_0.Name = "Swap2_0"
        Me.Swap2_0.Size = New System.Drawing.Size(75, 23)
        Me.Swap2_0.TabIndex = 25
        Me.Swap2_0.Text = "Swap"
        Me.Swap2_0.UseVisualStyleBackColor = False
        '
        'Swap3_0
        '
        Me.Swap3_0.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Swap3_0.BackColor = System.Drawing.Color.GreenYellow
        Me.Swap3_0.Location = New System.Drawing.Point(731, 541)
        Me.Swap3_0.Name = "Swap3_0"
        Me.Swap3_0.Size = New System.Drawing.Size(68, 23)
        Me.Swap3_0.TabIndex = 26
        Me.Swap3_0.Text = "Swap"
        Me.Swap3_0.UseVisualStyleBackColor = False
        '
        'Swap0_1
        '
        Me.Swap0_1.BackColor = System.Drawing.Color.GreenYellow
        Me.Swap0_1.Location = New System.Drawing.Point(731, 286)
        Me.Swap0_1.Name = "Swap0_1"
        Me.Swap0_1.Size = New System.Drawing.Size(93, 23)
        Me.Swap0_1.TabIndex = 27
        Me.Swap0_1.Text = "Swap"
        Me.Swap0_1.UseVisualStyleBackColor = False
        '
        'Pause_Pony_Button
        '
        Me.Pause_Pony_Button.Location = New System.Drawing.Point(561, 245)
        Me.Pause_Pony_Button.Name = "Pause_Pony_Button"
        Me.Pause_Pony_Button.Size = New System.Drawing.Size(75, 21)
        Me.Pause_Pony_Button.TabIndex = 5
        Me.Pause_Pony_Button.Text = "Pause Pony"
        Me.Pause_Pony_Button.UseVisualStyleBackColor = True
        '
        'Save_Button
        '
        Me.Save_Button.BackColor = System.Drawing.Color.IndianRed
        Me.Save_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Save_Button.Location = New System.Drawing.Point(561, 286)
        Me.Save_Button.Name = "Save_Button"
        Me.Save_Button.Size = New System.Drawing.Size(75, 21)
        Me.Save_Button.TabIndex = 28
        Me.Save_Button.Text = "SAVE"
        Me.Save_Button.UseVisualStyleBackColor = False
        '
        'Edit_Tags_Button
        '
        Me.Edit_Tags_Button.Location = New System.Drawing.Point(264, 286)
        Me.Edit_Tags_Button.Name = "Edit_Tags_Button"
        Me.Edit_Tags_Button.Size = New System.Drawing.Size(98, 21)
        Me.Edit_Tags_Button.TabIndex = 29
        Me.Edit_Tags_Button.Text = "Edit Tags"
        Me.Edit_Tags_Button.UseVisualStyleBackColor = True
        '
        'Set_Image_Centers_Button
        '
        Me.Set_Image_Centers_Button.Location = New System.Drawing.Point(417, 257)
        Me.Set_Image_Centers_Button.Name = "Set_Image_Centers_Button"
        Me.Set_Image_Centers_Button.Size = New System.Drawing.Size(81, 50)
        Me.Set_Image_Centers_Button.TabIndex = 30
        Me.Set_Image_Centers_Button.Text = "Set Image Centers"
        Me.Set_Image_Centers_Button.UseVisualStyleBackColor = True
        '
        'Pony_Editor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(948, 729)
        Me.Controls.Add(Me.Set_Image_Centers_Button)
        Me.Controls.Add(Me.Edit_Tags_Button)
        Me.Controls.Add(Me.Save_Button)
        Me.Controls.Add(Me.Pause_Pony_Button)
        Me.Controls.Add(Me.Swap0_1)
        Me.Controls.Add(Me.Swap3_0)
        Me.Controls.Add(Me.Swap2_0)
        Me.Controls.Add(Me.Swap1_0)
        Me.Controls.Add(Me.New_Interaction_Button)
        Me.Controls.Add(Me.New_Effect_Button)
        Me.Controls.Add(Me.New_Speech_Button)
        Me.Controls.Add(Me.New_Behavior_Button)
        Me.Controls.Add(Me.Slot2Label)
        Me.Controls.Add(Me.current_behavior_timeleft_label)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.current_behavior_label)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Pony_Effects_Grid)
        Me.Controls.Add(Me.Slot3Label)
        Me.Controls.Add(Me.Slot1Label)
        Me.Controls.Add(Me.Slot0Label)
        Me.Controls.Add(Me.Pony_Interaction_Grid)
        Me.Controls.Add(Me.Pony_Speech_Grid)
        Me.Controls.Add(Me.Pony_Behaviors_Grid)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Pony_Name_Box)
        Me.Controls.Add(Me.label35)
        Me.Controls.Add(Me.Pony_Preview_Panel)
        Me.MinimumSize = New System.Drawing.Size(964, 740)
        Me.Name = "Pony_Editor"
        Me.Text = "Pony Editor"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.Pony_Behaviors_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pony_Speech_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pony_Interaction_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pony_Effects_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pony_Preview_Panel As System.Windows.Forms.Panel
    Friend WithEvents label35 As System.Windows.Forms.Label
    Friend WithEvents Pony_Selection_View As System.Windows.Forms.ListView
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents new_pony_button As System.Windows.Forms.Button
    Friend WithEvents Pony_Name_Box As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Pony_Behaviors_Grid As System.Windows.Forms.DataGridView
    Friend WithEvents Pony_Speech_Grid As System.Windows.Forms.DataGridView
    Friend WithEvents Pony_Interaction_Grid As System.Windows.Forms.DataGridView
    Friend WithEvents Slot0Label As System.Windows.Forms.Label
    Friend WithEvents Slot1Label As System.Windows.Forms.Label
    Friend WithEvents Slot3Label As System.Windows.Forms.Label
    Friend WithEvents Pony_Effects_Grid As System.Windows.Forms.DataGridView
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents current_behavior_label As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents current_behavior_timeleft_label As System.Windows.Forms.Label
    Friend WithEvents Slot2Label As System.Windows.Forms.Label
    Friend WithEvents New_Behavior_Button As System.Windows.Forms.Button
    Friend WithEvents New_Speech_Button As System.Windows.Forms.Button
    Friend WithEvents New_Effect_Button As System.Windows.Forms.Button
    Friend WithEvents New_Interaction_Button As System.Windows.Forms.Button
    Friend WithEvents Swap1_0 As System.Windows.Forms.Button
    Friend WithEvents Swap2_0 As System.Windows.Forms.Button
    Friend WithEvents Swap3_0 As System.Windows.Forms.Button
    Friend WithEvents Swap0_1 As System.Windows.Forms.Button
    Friend WithEvents Speech_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Original_Speech_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Speech_Text As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sound_File As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Skip As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Effect_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Original_Effect_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Effect_Behavior As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Effect_Right_Image As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Effect_Left_Image As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Duration As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Repeat_Delay As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Location_Right As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Centering_Right As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Location_Left As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Centering_Left As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Follow_Pony As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Pause_Pony_Button As System.Windows.Forms.Button
    Friend WithEvents OpenPictureDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Save_Button As System.Windows.Forms.Button
    Friend WithEvents Interaction_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Original_Interaction_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Interaction_Probability As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Proximity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Targets As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Random_All As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Behaviors As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Delay As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Activate_Behavior As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Behavior_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Original_Behavior_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Probability As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Max_Duration As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Min_Duration As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Speed As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Right_Image As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Left_Image As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Movement As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Start_Speech As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents End_Speech As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Follow As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Linked_Behavior As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Link_Number As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Skip_on_Random As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Edit_Tags_Button As System.Windows.Forms.Button
    Friend WithEvents Set_Image_Centers_Button As System.Windows.Forms.Button
End Class
