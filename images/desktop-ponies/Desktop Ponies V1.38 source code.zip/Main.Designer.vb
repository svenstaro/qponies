﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MoveTimer = New System.Windows.Forms.Timer(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ShowAll_Radio = New System.Windows.Forms.RadioButton()
        Me.PonyFilter_Box = New System.Windows.Forms.CheckedListBox()
        Me.ShowAny_Radio = New System.Windows.Forms.RadioButton()
        Me.ShowExactly_Radio = New System.Windows.Forms.RadioButton()
        Me.Games_Button = New System.Windows.Forms.Button()
        Me.Load_Counts_Button = New System.Windows.Forms.Button()
        Me.Save_Counts_Button = New System.Windows.Forms.Button()
        Me.Reset_Counts_Button = New System.Windows.Forms.Button()
        Me.Pony_Editor_Button = New System.Windows.Forms.Button()
        Me.Zero_Ponies_Button = New System.Windows.Forms.Button()
        Me.Options_Button = New System.Windows.Forms.Button()
        Me.Go_Button = New System.Windows.Forms.Button()
        Me.CleanupTimer = New System.Windows.Forms.Timer(Me.components)
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MoveTimer
        '
        Me.MoveTimer.Interval = 30
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.AutoScroll = True
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.GroupBox1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Games_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Load_Counts_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Save_Counts_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Reset_Counts_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Pony_Editor_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Zero_Ponies_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Options_Button)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Go_Button)
        Me.SplitContainer1.Size = New System.Drawing.Size(701, 532)
        Me.SplitContainer1.SplitterDistance = 425
        Me.SplitContainer1.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ShowAll_Radio)
        Me.GroupBox1.Controls.Add(Me.PonyFilter_Box)
        Me.GroupBox1.Controls.Add(Me.ShowAny_Radio)
        Me.GroupBox1.Controls.Add(Me.ShowExactly_Radio)
        Me.GroupBox1.Location = New System.Drawing.Point(269, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(277, 99)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pony Filter"
        '
        'ShowAll_Radio
        '
        Me.ShowAll_Radio.AutoSize = True
        Me.ShowAll_Radio.Checked = True
        Me.ShowAll_Radio.Location = New System.Drawing.Point(13, 24)
        Me.ShowAll_Radio.Name = "ShowAll_Radio"
        Me.ShowAll_Radio.Size = New System.Drawing.Size(66, 17)
        Me.ShowAll_Radio.TabIndex = 9
        Me.ShowAll_Radio.TabStop = True
        Me.ShowAll_Radio.Text = "Show All"
        Me.ShowAll_Radio.UseVisualStyleBackColor = True
        '
        'PonyFilter_Box
        '
        Me.PonyFilter_Box.CheckOnClick = True
        Me.PonyFilter_Box.Enabled = False
        Me.PonyFilter_Box.FormattingEnabled = True
        Me.PonyFilter_Box.Items.AddRange(New Object() {"Main Ponies", "Supporting Ponies", "Alternate Art", "Fillies", "Pets", "Stallions", "Mares", "Alicorns", "Unicorns", "Pegasi", "Earth Ponies", "Non-Ponies", "Not Tagged"})
        Me.PonyFilter_Box.Location = New System.Drawing.Point(112, 14)
        Me.PonyFilter_Box.Name = "PonyFilter_Box"
        Me.PonyFilter_Box.Size = New System.Drawing.Size(148, 79)
        Me.PonyFilter_Box.TabIndex = 12
        '
        'ShowAny_Radio
        '
        Me.ShowAny_Radio.AutoSize = True
        Me.ShowAny_Radio.Location = New System.Drawing.Point(13, 48)
        Me.ShowAny_Radio.Name = "ShowAny_Radio"
        Me.ShowAny_Radio.Size = New System.Drawing.Size(105, 17)
        Me.ShowAny_Radio.TabIndex = 10
        Me.ShowAny_Radio.Text = "Any that match..."
        Me.ShowAny_Radio.UseVisualStyleBackColor = True
        '
        'ShowExactly_Radio
        '
        Me.ShowExactly_Radio.AutoSize = True
        Me.ShowExactly_Radio.Location = New System.Drawing.Point(13, 71)
        Me.ShowExactly_Radio.Name = "ShowExactly_Radio"
        Me.ShowExactly_Radio.Size = New System.Drawing.Size(68, 17)
        Me.ShowExactly_Radio.TabIndex = 11
        Me.ShowExactly_Radio.Text = "Exactly..."
        Me.ShowExactly_Radio.UseVisualStyleBackColor = True
        '
        'Games_Button
        '
        Me.Games_Button.Location = New System.Drawing.Point(571, 68)
        Me.Games_Button.Name = "Games_Button"
        Me.Games_Button.Size = New System.Drawing.Size(96, 23)
        Me.Games_Button.TabIndex = 8
        Me.Games_Button.Text = "MINI-GAMES"
        Me.Games_Button.UseVisualStyleBackColor = True
        '
        'Load_Counts_Button
        '
        Me.Load_Counts_Button.Location = New System.Drawing.Point(106, 62)
        Me.Load_Counts_Button.Name = "Load_Counts_Button"
        Me.Load_Counts_Button.Size = New System.Drawing.Size(43, 23)
        Me.Load_Counts_Button.TabIndex = 4
        Me.Load_Counts_Button.Text = "Load"
        Me.Load_Counts_Button.UseVisualStyleBackColor = True
        '
        'Save_Counts_Button
        '
        Me.Save_Counts_Button.Location = New System.Drawing.Point(106, 24)
        Me.Save_Counts_Button.Name = "Save_Counts_Button"
        Me.Save_Counts_Button.Size = New System.Drawing.Size(43, 23)
        Me.Save_Counts_Button.TabIndex = 3
        Me.Save_Counts_Button.Text = "Save"
        Me.Save_Counts_Button.UseVisualStyleBackColor = True
        '
        'Reset_Counts_Button
        '
        Me.Reset_Counts_Button.Location = New System.Drawing.Point(16, 68)
        Me.Reset_Counts_Button.Name = "Reset_Counts_Button"
        Me.Reset_Counts_Button.Size = New System.Drawing.Size(84, 23)
        Me.Reset_Counts_Button.TabIndex = 2
        Me.Reset_Counts_Button.Text = "Reset Counts"
        Me.Reset_Counts_Button.UseVisualStyleBackColor = True
        '
        'Pony_Editor_Button
        '
        Me.Pony_Editor_Button.Location = New System.Drawing.Point(166, 13)
        Me.Pony_Editor_Button.Name = "Pony_Editor_Button"
        Me.Pony_Editor_Button.Size = New System.Drawing.Size(92, 23)
        Me.Pony_Editor_Button.TabIndex = 5
        Me.Pony_Editor_Button.Text = "PONY EDITOR"
        Me.Pony_Editor_Button.UseVisualStyleBackColor = True
        '
        'Zero_Ponies_Button
        '
        Me.Zero_Ponies_Button.Location = New System.Drawing.Point(16, 12)
        Me.Zero_Ponies_Button.Name = "Zero_Ponies_Button"
        Me.Zero_Ponies_Button.Size = New System.Drawing.Size(75, 23)
        Me.Zero_Ponies_Button.TabIndex = 1
        Me.Zero_Ponies_Button.Text = "0 all ponies"
        Me.Zero_Ponies_Button.UseVisualStyleBackColor = True
        '
        'Options_Button
        '
        Me.Options_Button.Location = New System.Drawing.Point(166, 68)
        Me.Options_Button.Name = "Options_Button"
        Me.Options_Button.Size = New System.Drawing.Size(92, 23)
        Me.Options_Button.TabIndex = 6
        Me.Options_Button.Text = "OPTIONS"
        Me.Options_Button.UseVisualStyleBackColor = True
        '
        'Go_Button
        '
        Me.Go_Button.Location = New System.Drawing.Point(560, 24)
        Me.Go_Button.Name = "Go_Button"
        Me.Go_Button.Size = New System.Drawing.Size(118, 23)
        Me.Go_Button.TabIndex = 7
        Me.Go_Button.Text = "GIVE ME PONIES!"
        Me.Go_Button.UseVisualStyleBackColor = True
        '
        'CleanupTimer
        '
        Me.CleanupTimer.Interval = 5000
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoSize = True
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(701, 532)
        Me.Controls.Add(Me.SplitContainer1)
        Me.DoubleBuffered = True
        Me.Name = "Main"
        Me.Text = "Deskop Ponies V1.38"
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MoveTimer As System.Windows.Forms.Timer
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Go_Button As System.Windows.Forms.Button
    Friend WithEvents Options_Button As System.Windows.Forms.Button
    Friend WithEvents Zero_Ponies_Button As System.Windows.Forms.Button
    Friend WithEvents Pony_Editor_Button As System.Windows.Forms.Button
    Friend WithEvents CleanupTimer As System.Windows.Forms.Timer
    Friend WithEvents Load_Counts_Button As System.Windows.Forms.Button
    Friend WithEvents Save_Counts_Button As System.Windows.Forms.Button
    Friend WithEvents Reset_Counts_Button As System.Windows.Forms.Button
    Friend WithEvents Games_Button As System.Windows.Forms.Button
    Friend WithEvents PonyFilter_Box As System.Windows.Forms.CheckedListBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ShowAny_Radio As System.Windows.Forms.RadioButton
    Friend WithEvents ShowExactly_Radio As System.Windows.Forms.RadioButton
    Friend WithEvents ShowAll_Radio As System.Windows.Forms.RadioButton

End Class
