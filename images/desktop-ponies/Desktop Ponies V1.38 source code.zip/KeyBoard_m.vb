﻿

'Finds out what keys are currently pressed

Imports System.Windows.Forms
Imports System.Runtime.InteropServices

Public Class KeyboardInfo
    Public Sub New()
    End Sub
    <DllImport("user32")> _
    Private Shared Function GetKeyState(ByVal vKey As Integer) As Short
    End Function

    Public Shared Function IsPressed(ByVal key As Keys) As Boolean
        Dim keyState As Short = GetKeyState(CInt(key))
        Dim high__2 As Integer = High(keyState)
        Dim pressed As Boolean = high__2 = 1
        Return pressed
    End Function
    Private Shared Function High(ByVal keyState As Integer) As Integer
        Return If(keyState > 0, keyState >> &H10, (keyState >> &H10) And &H1)
    End Function
End Class

