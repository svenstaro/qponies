﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Options
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Avoidance_Loc_Y = New System.Windows.Forms.NumericUpDown()
        Me.Avoidance_Size_Y = New System.Windows.Forms.NumericUpDown()
        Me.Avoidance_Loc_X = New System.Windows.Forms.NumericUpDown()
        Me.Avoidance_Size_X = New System.Windows.Forms.NumericUpDown()
        Me.Avoidance_Preview_Image = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ScreenSelection_Box = New System.Windows.Forms.ListBox()
        Me.No_Monitor_Warning = New System.Windows.Forms.Label()
        Me.Cursor_Avoidance_Enabled = New System.Windows.Forms.CheckBox()
        Me.Cursor_zone_counter = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pony_Dragging_Enabled = New System.Windows.Forms.CheckBox()
        Me.Pony_Speak_Chance_Counter = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Max_Pony_Counter = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Close_Button = New System.Windows.Forms.Button()
        Me.Save_Button = New System.Windows.Forms.Button()
        Me.Load_Button = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Reset_Button = New System.Windows.Forms.Button()
        Me.Effects_Enabled = New System.Windows.Forms.CheckBox()
        Me.Sounds_Enabled = New System.Windows.Forms.CheckBox()
        Me.Interactions_Enabled = New System.Windows.Forms.CheckBox()
        Me.Interactions_Disabled_Label = New System.Windows.Forms.Label()
        Me.Interactions_error_label = New System.Windows.Forms.Label()
        Me.Window_Avoidance_Enabled = New System.Windows.Forms.CheckBox()
        Me.Disable_Speech = New System.Windows.Forms.CheckBox()
        Me.Interaction_Errors_Displayed = New System.Windows.Forms.CheckBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PoniesAvoidPonies = New System.Windows.Forms.CheckBox()
        Me.PoniesStayInBoxes = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Scale_Slider = New System.Windows.Forms.TrackBar()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ImageScale_Label = New System.Windows.Forms.Label()
        Me.Custom_Filters_Button = New System.Windows.Forms.Button()
        Me.Sounds_Disabled_Label = New System.Windows.Forms.Label()
        Me.ScreenSaver_Sounds_Checkbox = New System.Windows.Forms.CheckBox()
        Me.Sounds_Limit1_Radio = New System.Windows.Forms.RadioButton()
        Me.Sounds_Per_Pony_Radio = New System.Windows.Forms.RadioButton()
        Me.Teleport_Checkbox = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.screensaver_image_warning_label = New System.Windows.Forms.Label()
        Me.screensaver_color_warning_label = New System.Windows.Forms.Label()
        Me.Color_Select_Button = New System.Windows.Forms.Button()
        Me.Screensaver_background_image_select_button = New System.Windows.Forms.Button()
        Me.Screensaver_use_bgimage_checkbox = New System.Windows.Forms.RadioButton()
        Me.Screensaver_solidcolor_checkbox = New System.Windows.Forms.RadioButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Screensaver_Transparent_Checkbox = New System.Windows.Forms.RadioButton()
        CType(Me.Avoidance_Loc_Y, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Avoidance_Size_Y, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Avoidance_Loc_X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Avoidance_Size_X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Avoidance_Preview_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cursor_zone_counter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pony_Speak_Chance_Counter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Max_Pony_Counter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.Scale_Slider, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(102, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Location (X,Y)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "Size (X,Y)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(116, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "(Pony avoidance zone)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(255, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Pony Avoidance Preview:"
        '
        'Avoidance_Loc_Y
        '
        Me.Avoidance_Loc_Y.Location = New System.Drawing.Point(119, 129)
        Me.Avoidance_Loc_Y.Name = "Avoidance_Loc_Y"
        Me.Avoidance_Loc_Y.Size = New System.Drawing.Size(46, 20)
        Me.Avoidance_Loc_Y.TabIndex = 19
        '
        'Avoidance_Size_Y
        '
        Me.Avoidance_Size_Y.Location = New System.Drawing.Point(19, 129)
        Me.Avoidance_Size_Y.Name = "Avoidance_Size_Y"
        Me.Avoidance_Size_Y.Size = New System.Drawing.Size(46, 20)
        Me.Avoidance_Size_Y.TabIndex = 17
        '
        'Avoidance_Loc_X
        '
        Me.Avoidance_Loc_X.Location = New System.Drawing.Point(119, 91)
        Me.Avoidance_Loc_X.Name = "Avoidance_Loc_X"
        Me.Avoidance_Loc_X.Size = New System.Drawing.Size(46, 20)
        Me.Avoidance_Loc_X.TabIndex = 18
        '
        'Avoidance_Size_X
        '
        Me.Avoidance_Size_X.Location = New System.Drawing.Point(19, 91)
        Me.Avoidance_Size_X.Name = "Avoidance_Size_X"
        Me.Avoidance_Size_X.Size = New System.Drawing.Size(46, 20)
        Me.Avoidance_Size_X.TabIndex = 16
        '
        'Avoidance_Preview_Image
        '
        Me.Avoidance_Preview_Image.Location = New System.Drawing.Point(210, 40)
        Me.Avoidance_Preview_Image.Name = "Avoidance_Preview_Image"
        Me.Avoidance_Preview_Image.Size = New System.Drawing.Size(227, 123)
        Me.Avoidance_Preview_Image.TabIndex = 15
        Me.Avoidance_Preview_Image.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 258)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Monitors to use:"
        '
        'ScreenSelection_Box
        '
        Me.ScreenSelection_Box.FormattingEnabled = True
        Me.ScreenSelection_Box.Location = New System.Drawing.Point(62, 274)
        Me.ScreenSelection_Box.Name = "ScreenSelection_Box"
        Me.ScreenSelection_Box.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ScreenSelection_Box.Size = New System.Drawing.Size(135, 43)
        Me.ScreenSelection_Box.TabIndex = 7
        '
        'No_Monitor_Warning
        '
        Me.No_Monitor_Warning.AutoSize = True
        Me.No_Monitor_Warning.ForeColor = System.Drawing.Color.Maroon
        Me.No_Monitor_Warning.Location = New System.Drawing.Point(34, 320)
        Me.No_Monitor_Warning.Name = "No_Monitor_Warning"
        Me.No_Monitor_Warning.Size = New System.Drawing.Size(197, 13)
        Me.No_Monitor_Warning.TabIndex = 26
        Me.No_Monitor_Warning.Text = "(You need at least one monitor selected)"
        Me.No_Monitor_Warning.Visible = False
        '
        'Cursor_Avoidance_Enabled
        '
        Me.Cursor_Avoidance_Enabled.AutoSize = True
        Me.Cursor_Avoidance_Enabled.Checked = True
        Me.Cursor_Avoidance_Enabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cursor_Avoidance_Enabled.Location = New System.Drawing.Point(31, 109)
        Me.Cursor_Avoidance_Enabled.Name = "Cursor_Avoidance_Enabled"
        Me.Cursor_Avoidance_Enabled.Size = New System.Drawing.Size(245, 17)
        Me.Cursor_Avoidance_Enabled.TabIndex = 3
        Me.Cursor_Avoidance_Enabled.Text = "Ponies avoid cursor / stop when hovered over"
        Me.Cursor_Avoidance_Enabled.UseVisualStyleBackColor = True
        '
        'Cursor_zone_counter
        '
        Me.Cursor_zone_counter.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.Cursor_zone_counter.Location = New System.Drawing.Point(37, 131)
        Me.Cursor_zone_counter.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.Cursor_zone_counter.Name = "Cursor_zone_counter"
        Me.Cursor_zone_counter.Size = New System.Drawing.Size(76, 20)
        Me.Cursor_zone_counter.TabIndex = 4
        Me.Cursor_zone_counter.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(120, 130)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(175, 13)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Size of area around cursor to avoid."
        '
        'Pony_Dragging_Enabled
        '
        Me.Pony_Dragging_Enabled.AutoSize = True
        Me.Pony_Dragging_Enabled.Checked = True
        Me.Pony_Dragging_Enabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Pony_Dragging_Enabled.Location = New System.Drawing.Point(31, 153)
        Me.Pony_Dragging_Enabled.Name = "Pony_Dragging_Enabled"
        Me.Pony_Dragging_Enabled.Size = New System.Drawing.Size(246, 17)
        Me.Pony_Dragging_Enabled.TabIndex = 5
        Me.Pony_Dragging_Enabled.Text = "Ponies can be dragged around with the mouse"
        Me.Pony_Dragging_Enabled.UseVisualStyleBackColor = True
        '
        'Pony_Speak_Chance_Counter
        '
        Me.Pony_Speak_Chance_Counter.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.Pony_Speak_Chance_Counter.Location = New System.Drawing.Point(203, 33)
        Me.Pony_Speak_Chance_Counter.Name = "Pony_Speak_Chance_Counter"
        Me.Pony_Speak_Chance_Counter.Size = New System.Drawing.Size(50, 20)
        Me.Pony_Speak_Chance_Counter.TabIndex = 1
        Me.Pony_Speak_Chance_Counter.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 35)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(173, 13)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Pony Speaking random chance (%)"
        '
        'Max_Pony_Counter
        '
        Me.Max_Pony_Counter.Location = New System.Drawing.Point(391, 123)
        Me.Max_Pony_Counter.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.Max_Pony_Counter.Name = "Max_Pony_Counter"
        Me.Max_Pony_Counter.Size = New System.Drawing.Size(50, 20)
        Me.Max_Pony_Counter.TabIndex = 15
        Me.Max_Pony_Counter.Value = New Decimal(New Integer() {75, 0, 0, 0})
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(340, 105)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(87, 13)
        Me.Label10.TabIndex = 36
        Me.Label10.Text = "Max # of Ponies:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.DarkRed
        Me.Label11.Location = New System.Drawing.Point(319, 151)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(216, 13)
        Me.Label11.TabIndex = 37
        Me.Label11.Text = "**** WARNING: Too many ponies might  ****"
        '
        'Close_Button
        '
        Me.Close_Button.Location = New System.Drawing.Point(707, 528)
        Me.Close_Button.Name = "Close_Button"
        Me.Close_Button.Size = New System.Drawing.Size(75, 23)
        Me.Close_Button.TabIndex = 23
        Me.Close_Button.Text = "Close"
        Me.Close_Button.UseVisualStyleBackColor = True
        '
        'Save_Button
        '
        Me.Save_Button.Location = New System.Drawing.Point(31, 528)
        Me.Save_Button.Name = "Save_Button"
        Me.Save_Button.Size = New System.Drawing.Size(75, 23)
        Me.Save_Button.TabIndex = 20
        Me.Save_Button.Text = "SAVE"
        Me.Save_Button.UseVisualStyleBackColor = True
        '
        'Load_Button
        '
        Me.Load_Button.Location = New System.Drawing.Point(184, 528)
        Me.Load_Button.Name = "Load_Button"
        Me.Load_Button.Size = New System.Drawing.Size(75, 23)
        Me.Load_Button.TabIndex = 21
        Me.Load_Button.Text = "LOAD"
        Me.Load_Button.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.DarkRed
        Me.Label12.Location = New System.Drawing.Point(336, 164)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(177, 13)
        Me.Label12.TabIndex = 41
        Me.Label12.Text = "**** make your computer slower  ****"
        '
        'Reset_Button
        '
        Me.Reset_Button.Location = New System.Drawing.Point(569, 528)
        Me.Reset_Button.Name = "Reset_Button"
        Me.Reset_Button.Size = New System.Drawing.Size(75, 23)
        Me.Reset_Button.TabIndex = 22
        Me.Reset_Button.Text = "RESET"
        Me.Reset_Button.UseVisualStyleBackColor = True
        '
        'Effects_Enabled
        '
        Me.Effects_Enabled.AutoSize = True
        Me.Effects_Enabled.Checked = True
        Me.Effects_Enabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Effects_Enabled.Location = New System.Drawing.Point(413, 200)
        Me.Effects_Enabled.Name = "Effects_Enabled"
        Me.Effects_Enabled.Size = New System.Drawing.Size(95, 17)
        Me.Effects_Enabled.TabIndex = 12
        Me.Effects_Enabled.Text = "Enable Effects"
        Me.Effects_Enabled.UseVisualStyleBackColor = True
        '
        'Sounds_Enabled
        '
        Me.Sounds_Enabled.AutoSize = True
        Me.Sounds_Enabled.Location = New System.Drawing.Point(559, 101)
        Me.Sounds_Enabled.Name = "Sounds_Enabled"
        Me.Sounds_Enabled.Size = New System.Drawing.Size(98, 17)
        Me.Sounds_Enabled.TabIndex = 11
        Me.Sounds_Enabled.Text = "Enable Sounds"
        Me.Sounds_Enabled.UseVisualStyleBackColor = True
        '
        'Interactions_Enabled
        '
        Me.Interactions_Enabled.AutoSize = True
        Me.Interactions_Enabled.Checked = True
        Me.Interactions_Enabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Interactions_Enabled.Location = New System.Drawing.Point(46, 200)
        Me.Interactions_Enabled.Name = "Interactions_Enabled"
        Me.Interactions_Enabled.Size = New System.Drawing.Size(117, 17)
        Me.Interactions_Enabled.TabIndex = 13
        Me.Interactions_Enabled.Text = "Enable Interactions"
        Me.Interactions_Enabled.UseVisualStyleBackColor = True
        '
        'Interactions_Disabled_Label
        '
        Me.Interactions_Disabled_Label.AutoSize = True
        Me.Interactions_Disabled_Label.ForeColor = System.Drawing.Color.DarkRed
        Me.Interactions_Disabled_Label.Location = New System.Drawing.Point(3, 214)
        Me.Interactions_Disabled_Label.Name = "Interactions_Disabled_Label"
        Me.Interactions_Disabled_Label.Size = New System.Drawing.Size(191, 13)
        Me.Interactions_Disabled_Label.TabIndex = 47
        Me.Interactions_Disabled_Label.Text = "*Disabled due to no Interactions.ini file*"
        Me.Interactions_Disabled_Label.Visible = False
        '
        'Interactions_error_label
        '
        Me.Interactions_error_label.AutoSize = True
        Me.Interactions_error_label.ForeColor = System.Drawing.Color.DarkRed
        Me.Interactions_error_label.Location = New System.Drawing.Point(45, 227)
        Me.Interactions_error_label.Name = "Interactions_error_label"
        Me.Interactions_error_label.Size = New System.Drawing.Size(113, 13)
        Me.Interactions_error_label.TabIndex = 48
        Me.Interactions_error_label.Text = "*Disabled due to error*"
        Me.Interactions_error_label.Visible = False
        '
        'Window_Avoidance_Enabled
        '
        Me.Window_Avoidance_Enabled.AutoSize = True
        Me.Window_Avoidance_Enabled.Location = New System.Drawing.Point(559, 12)
        Me.Window_Avoidance_Enabled.Name = "Window_Avoidance_Enabled"
        Me.Window_Avoidance_Enabled.Size = New System.Drawing.Size(184, 17)
        Me.Window_Avoidance_Enabled.TabIndex = 8
        Me.Window_Avoidance_Enabled.Text = "Ponies try to avoid other windows"
        Me.Window_Avoidance_Enabled.UseVisualStyleBackColor = True
        '
        'Disable_Speech
        '
        Me.Disable_Speech.AutoSize = True
        Me.Disable_Speech.Location = New System.Drawing.Point(60, 62)
        Me.Disable_Speech.Name = "Disable_Speech"
        Me.Disable_Speech.Size = New System.Drawing.Size(132, 17)
        Me.Disable_Speech.TabIndex = 2
        Me.Disable_Speech.Text = "Disable all speech text"
        Me.Disable_Speech.UseVisualStyleBackColor = True
        '
        'Interaction_Errors_Displayed
        '
        Me.Interaction_Errors_Displayed.AutoSize = True
        Me.Interaction_Errors_Displayed.Location = New System.Drawing.Point(237, 200)
        Me.Interaction_Errors_Displayed.Name = "Interaction_Errors_Displayed"
        Me.Interaction_Errors_Displayed.Size = New System.Drawing.Size(135, 17)
        Me.Interaction_Errors_Displayed.TabIndex = 14
        Me.Interaction_Errors_Displayed.Text = "Show Interaction errors"
        Me.Interaction_Errors_Displayed.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(213, 220)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(183, 13)
        Me.Label14.TabIndex = 52
        Me.Label14.Text = "(Unchecked: Silently disable on error)"
        '
        'PoniesAvoidPonies
        '
        Me.PoniesAvoidPonies.AutoSize = True
        Me.PoniesAvoidPonies.Location = New System.Drawing.Point(580, 33)
        Me.PoniesAvoidPonies.Name = "PoniesAvoidPonies"
        Me.PoniesAvoidPonies.Size = New System.Drawing.Size(174, 17)
        Me.PoniesAvoidPonies.TabIndex = 9
        Me.PoniesAvoidPonies.Text = "Ponies try to avoid other ponies"
        Me.PoniesAvoidPonies.UseVisualStyleBackColor = True
        '
        'PoniesStayInBoxes
        '
        Me.PoniesStayInBoxes.AutoSize = True
        Me.PoniesStayInBoxes.Location = New System.Drawing.Point(580, 51)
        Me.PoniesStayInBoxes.Name = "PoniesStayInBoxes"
        Me.PoniesStayInBoxes.Size = New System.Drawing.Size(228, 17)
        Me.PoniesStayInBoxes.TabIndex = 10
        Me.PoniesStayInBoxes.Text = "Ponies don't leave windows they are inside"
        Me.PoniesStayInBoxes.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Avoidance_Loc_Y)
        Me.GroupBox1.Controls.Add(Me.Avoidance_Size_Y)
        Me.GroupBox1.Controls.Add(Me.Avoidance_Loc_X)
        Me.GroupBox1.Controls.Add(Me.Avoidance_Size_X)
        Me.GroupBox1.Controls.Add(Me.Avoidance_Preview_Image)
        Me.GroupBox1.Location = New System.Drawing.Point(27, 347)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(465, 172)
        Me.GroupBox1.TabIndex = 55
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Everfree forest area settings:"
        '
        'Scale_Slider
        '
        Me.Scale_Slider.LargeChange = 25
        Me.Scale_Slider.Location = New System.Drawing.Point(305, 51)
        Me.Scale_Slider.Maximum = 500
        Me.Scale_Slider.Minimum = 25
        Me.Scale_Slider.Name = "Scale_Slider"
        Me.Scale_Slider.Size = New System.Drawing.Size(217, 45)
        Me.Scale_Slider.TabIndex = 6
        Me.Scale_Slider.TickFrequency = 25
        Me.Scale_Slider.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        Me.Scale_Slider.Value = 100
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(305, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 57
        Me.Label4.Text = "Pony Sizes:"
        '
        'ImageScale_Label
        '
        Me.ImageScale_Label.AutoSize = True
        Me.ImageScale_Label.Location = New System.Drawing.Point(500, 32)
        Me.ImageScale_Label.Name = "ImageScale_Label"
        Me.ImageScale_Label.Size = New System.Drawing.Size(18, 13)
        Me.ImageScale_Label.TabIndex = 58
        Me.ImageScale_Label.Text = "1x"
        '
        'Custom_Filters_Button
        '
        Me.Custom_Filters_Button.Location = New System.Drawing.Point(361, 528)
        Me.Custom_Filters_Button.Name = "Custom_Filters_Button"
        Me.Custom_Filters_Button.Size = New System.Drawing.Size(103, 23)
        Me.Custom_Filters_Button.TabIndex = 59
        Me.Custom_Filters_Button.Text = "Custom Filters"
        Me.Custom_Filters_Button.UseVisualStyleBackColor = True
        '
        'Sounds_Disabled_Label
        '
        Me.Sounds_Disabled_Label.AutoSize = True
        Me.Sounds_Disabled_Label.ForeColor = System.Drawing.Color.DarkRed
        Me.Sounds_Disabled_Label.Location = New System.Drawing.Point(529, 121)
        Me.Sounds_Disabled_Label.Name = "Sounds_Disabled_Label"
        Me.Sounds_Disabled_Label.Size = New System.Drawing.Size(257, 13)
        Me.Sounds_Disabled_Label.TabIndex = 60
        Me.Sounds_Disabled_Label.Text = "*Disabled due to missing or incorrect DirectX version*"
        Me.Sounds_Disabled_Label.Visible = False
        '
        'ScreenSaver_Sounds_Checkbox
        '
        Me.ScreenSaver_Sounds_Checkbox.AutoSize = True
        Me.ScreenSaver_Sounds_Checkbox.Location = New System.Drawing.Point(27, 28)
        Me.ScreenSaver_Sounds_Checkbox.Name = "ScreenSaver_Sounds_Checkbox"
        Me.ScreenSaver_Sounds_Checkbox.Size = New System.Drawing.Size(203, 17)
        Me.ScreenSaver_Sounds_Checkbox.TabIndex = 61
        Me.ScreenSaver_Sounds_Checkbox.Text = "Enable Sounds in ScreenSaver mode"
        Me.ScreenSaver_Sounds_Checkbox.UseVisualStyleBackColor = True
        '
        'Sounds_Limit1_Radio
        '
        Me.Sounds_Limit1_Radio.AutoSize = True
        Me.Sounds_Limit1_Radio.Location = New System.Drawing.Point(582, 139)
        Me.Sounds_Limit1_Radio.Name = "Sounds_Limit1_Radio"
        Me.Sounds_Limit1_Radio.Size = New System.Drawing.Size(159, 17)
        Me.Sounds_Limit1_Radio.TabIndex = 62
        Me.Sounds_Limit1_Radio.TabStop = True
        Me.Sounds_Limit1_Radio.Text = "Limit sounds to one at a time"
        Me.Sounds_Limit1_Radio.UseVisualStyleBackColor = True
        '
        'Sounds_Per_Pony_Radio
        '
        Me.Sounds_Per_Pony_Radio.AutoSize = True
        Me.Sounds_Per_Pony_Radio.Location = New System.Drawing.Point(582, 162)
        Me.Sounds_Per_Pony_Radio.Name = "Sounds_Per_Pony_Radio"
        Me.Sounds_Per_Pony_Radio.Size = New System.Drawing.Size(160, 17)
        Me.Sounds_Per_Pony_Radio.TabIndex = 63
        Me.Sounds_Per_Pony_Radio.TabStop = True
        Me.Sounds_Per_Pony_Radio.Text = "Limit sounds to one per pony"
        Me.Sounds_Per_Pony_Radio.UseVisualStyleBackColor = True
        '
        'Teleport_Checkbox
        '
        Me.Teleport_Checkbox.AutoSize = True
        Me.Teleport_Checkbox.Location = New System.Drawing.Point(228, 284)
        Me.Teleport_Checkbox.Name = "Teleport_Checkbox"
        Me.Teleport_Checkbox.Size = New System.Drawing.Size(306, 17)
        Me.Teleport_Checkbox.TabIndex = 64
        Me.Teleport_Checkbox.Text = "Ponies teleport out of disallowed areas/screens immediately"
        Me.Teleport_Checkbox.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(248, 304)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(274, 13)
        Me.Label9.TabIndex = 65
        Me.Label9.Text = "(Unchecked: Ponies slowly walk out of disallowed areas)"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.screensaver_image_warning_label)
        Me.GroupBox2.Controls.Add(Me.screensaver_color_warning_label)
        Me.GroupBox2.Controls.Add(Me.Color_Select_Button)
        Me.GroupBox2.Controls.Add(Me.Screensaver_background_image_select_button)
        Me.GroupBox2.Controls.Add(Me.Screensaver_use_bgimage_checkbox)
        Me.GroupBox2.Controls.Add(Me.Screensaver_solidcolor_checkbox)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Screensaver_Transparent_Checkbox)
        Me.GroupBox2.Controls.Add(Me.ScreenSaver_Sounds_Checkbox)
        Me.GroupBox2.Location = New System.Drawing.Point(532, 333)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(254, 186)
        Me.GroupBox2.TabIndex = 66
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "ScreenSaver Options"
        '
        'screensaver_image_warning_label
        '
        Me.screensaver_image_warning_label.AutoSize = True
        Me.screensaver_image_warning_label.ForeColor = System.Drawing.Color.DarkRed
        Me.screensaver_image_warning_label.Location = New System.Drawing.Point(64, 164)
        Me.screensaver_image_warning_label.Name = "screensaver_image_warning_label"
        Me.screensaver_image_warning_label.Size = New System.Drawing.Size(120, 13)
        Me.screensaver_image_warning_label.TabIndex = 72
        Me.screensaver_image_warning_label.Text = "*No image selected yet*"
        Me.screensaver_image_warning_label.Visible = False
        '
        'screensaver_color_warning_label
        '
        Me.screensaver_color_warning_label.AutoSize = True
        Me.screensaver_color_warning_label.ForeColor = System.Drawing.Color.DarkRed
        Me.screensaver_color_warning_label.Location = New System.Drawing.Point(64, 127)
        Me.screensaver_color_warning_label.Name = "screensaver_color_warning_label"
        Me.screensaver_color_warning_label.Size = New System.Drawing.Size(115, 13)
        Me.screensaver_color_warning_label.TabIndex = 67
        Me.screensaver_color_warning_label.Text = "*No color selected yet*"
        Me.screensaver_color_warning_label.Visible = False
        '
        'Color_Select_Button
        '
        Me.Color_Select_Button.Location = New System.Drawing.Point(134, 106)
        Me.Color_Select_Button.Name = "Color_Select_Button"
        Me.Color_Select_Button.Size = New System.Drawing.Size(88, 23)
        Me.Color_Select_Button.TabIndex = 71
        Me.Color_Select_Button.Text = "Select Color"
        Me.Color_Select_Button.UseVisualStyleBackColor = True
        '
        'Screensaver_background_image_select_button
        '
        Me.Screensaver_background_image_select_button.Location = New System.Drawing.Point(134, 143)
        Me.Screensaver_background_image_select_button.Name = "Screensaver_background_image_select_button"
        Me.Screensaver_background_image_select_button.Size = New System.Drawing.Size(88, 23)
        Me.Screensaver_background_image_select_button.TabIndex = 70
        Me.Screensaver_background_image_select_button.Text = "Select Image"
        Me.Screensaver_background_image_select_button.UseVisualStyleBackColor = True
        '
        'Screensaver_use_bgimage_checkbox
        '
        Me.Screensaver_use_bgimage_checkbox.AutoSize = True
        Me.Screensaver_use_bgimage_checkbox.Location = New System.Drawing.Point(27, 146)
        Me.Screensaver_use_bgimage_checkbox.Name = "Screensaver_use_bgimage_checkbox"
        Me.Screensaver_use_bgimage_checkbox.Size = New System.Drawing.Size(91, 17)
        Me.Screensaver_use_bgimage_checkbox.TabIndex = 69
        Me.Screensaver_use_bgimage_checkbox.TabStop = True
        Me.Screensaver_use_bgimage_checkbox.Text = "Custom image"
        Me.Screensaver_use_bgimage_checkbox.UseVisualStyleBackColor = True
        '
        'Screensaver_solidcolor_checkbox
        '
        Me.Screensaver_solidcolor_checkbox.AutoSize = True
        Me.Screensaver_solidcolor_checkbox.Location = New System.Drawing.Point(27, 109)
        Me.Screensaver_solidcolor_checkbox.Name = "Screensaver_solidcolor_checkbox"
        Me.Screensaver_solidcolor_checkbox.Size = New System.Drawing.Size(75, 17)
        Me.Screensaver_solidcolor_checkbox.TabIndex = 68
        Me.Screensaver_solidcolor_checkbox.TabStop = True
        Me.Screensaver_solidcolor_checkbox.Text = "Solid Color"
        Me.Screensaver_solidcolor_checkbox.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(11, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(133, 13)
        Me.Label13.TabIndex = 67
        Me.Label13.Text = "ScreenSaver Background:"
        '
        'Screensaver_Transparent_Checkbox
        '
        Me.Screensaver_Transparent_Checkbox.AutoSize = True
        Me.Screensaver_Transparent_Checkbox.Location = New System.Drawing.Point(27, 73)
        Me.Screensaver_Transparent_Checkbox.Name = "Screensaver_Transparent_Checkbox"
        Me.Screensaver_Transparent_Checkbox.Size = New System.Drawing.Size(117, 17)
        Me.Screensaver_Transparent_Checkbox.TabIndex = 62
        Me.Screensaver_Transparent_Checkbox.TabStop = True
        Me.Screensaver_Transparent_Checkbox.Text = "None (Transparent)"
        Me.Screensaver_Transparent_Checkbox.UseVisualStyleBackColor = True
        '
        'Options
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(822, 564)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Teleport_Checkbox)
        Me.Controls.Add(Me.Sounds_Per_Pony_Radio)
        Me.Controls.Add(Me.Sounds_Limit1_Radio)
        Me.Controls.Add(Me.Sounds_Disabled_Label)
        Me.Controls.Add(Me.Custom_Filters_Button)
        Me.Controls.Add(Me.ImageScale_Label)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Scale_Slider)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PoniesStayInBoxes)
        Me.Controls.Add(Me.PoniesAvoidPonies)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Interaction_Errors_Displayed)
        Me.Controls.Add(Me.Disable_Speech)
        Me.Controls.Add(Me.Window_Avoidance_Enabled)
        Me.Controls.Add(Me.Interactions_error_label)
        Me.Controls.Add(Me.Interactions_Disabled_Label)
        Me.Controls.Add(Me.Interactions_Enabled)
        Me.Controls.Add(Me.Sounds_Enabled)
        Me.Controls.Add(Me.Effects_Enabled)
        Me.Controls.Add(Me.Reset_Button)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Load_Button)
        Me.Controls.Add(Me.Save_Button)
        Me.Controls.Add(Me.Close_Button)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Max_Pony_Counter)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Pony_Speak_Chance_Counter)
        Me.Controls.Add(Me.Pony_Dragging_Enabled)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Cursor_zone_counter)
        Me.Controls.Add(Me.Cursor_Avoidance_Enabled)
        Me.Controls.Add(Me.No_Monitor_Warning)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ScreenSelection_Box)
        Me.Name = "Options"
        Me.Text = "Options"
        CType(Me.Avoidance_Loc_Y, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Avoidance_Size_Y, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Avoidance_Loc_X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Avoidance_Size_X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Avoidance_Preview_Image, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cursor_zone_counter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pony_Speak_Chance_Counter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Max_Pony_Counter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Scale_Slider, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Avoidance_Loc_Y As System.Windows.Forms.NumericUpDown
    Friend WithEvents Avoidance_Size_Y As System.Windows.Forms.NumericUpDown
    Friend WithEvents Avoidance_Loc_X As System.Windows.Forms.NumericUpDown
    Friend WithEvents Avoidance_Size_X As System.Windows.Forms.NumericUpDown
    Friend WithEvents Avoidance_Preview_Image As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ScreenSelection_Box As System.Windows.Forms.ListBox
    Friend WithEvents No_Monitor_Warning As System.Windows.Forms.Label
    Friend WithEvents Cursor_Avoidance_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents Cursor_zone_counter As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pony_Dragging_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents Pony_Speak_Chance_Counter As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Max_Pony_Counter As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Close_Button As System.Windows.Forms.Button
    Friend WithEvents Save_Button As System.Windows.Forms.Button
    Friend WithEvents Load_Button As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Reset_Button As System.Windows.Forms.Button
    Friend WithEvents Effects_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents Sounds_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents Interactions_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents Interactions_Disabled_Label As System.Windows.Forms.Label
    Friend WithEvents Interactions_error_label As System.Windows.Forms.Label
    Friend WithEvents Window_Avoidance_Enabled As System.Windows.Forms.CheckBox
    Friend WithEvents Disable_Speech As System.Windows.Forms.CheckBox
    Friend WithEvents Interaction_Errors_Displayed As System.Windows.Forms.CheckBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents PoniesAvoidPonies As System.Windows.Forms.CheckBox
    Friend WithEvents PoniesStayInBoxes As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Scale_Slider As System.Windows.Forms.TrackBar
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ImageScale_Label As System.Windows.Forms.Label
    Friend WithEvents Custom_Filters_Button As System.Windows.Forms.Button
    Friend WithEvents Sounds_Disabled_Label As System.Windows.Forms.Label
    Friend WithEvents ScreenSaver_Sounds_Checkbox As System.Windows.Forms.CheckBox
    Friend WithEvents Sounds_Limit1_Radio As System.Windows.Forms.RadioButton
    Friend WithEvents Sounds_Per_Pony_Radio As System.Windows.Forms.RadioButton
    Friend WithEvents Teleport_Checkbox As System.Windows.Forms.CheckBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Screensaver_background_image_select_button As System.Windows.Forms.Button
    Friend WithEvents Screensaver_use_bgimage_checkbox As System.Windows.Forms.RadioButton
    Friend WithEvents Screensaver_solidcolor_checkbox As System.Windows.Forms.RadioButton
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Screensaver_Transparent_Checkbox As System.Windows.Forms.RadioButton
    Friend WithEvents Color_Select_Button As System.Windows.Forms.Button
    Friend WithEvents screensaver_image_warning_label As System.Windows.Forms.Label
    Friend WithEvents screensaver_color_warning_label As System.Windows.Forms.Label
End Class
