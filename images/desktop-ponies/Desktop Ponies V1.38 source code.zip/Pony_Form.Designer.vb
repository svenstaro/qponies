﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pony_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Pony_Image = New System.Windows.Forms.PictureBox()
        Me.RightClickMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddPonyMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Sleep = New System.Windows.Forms.ToolStripMenuItem()
        Me.Sleep_All = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.Take_Control_P1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Take_Control_P2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.Return_To_Menu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Show_Options = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Quit = New System.Windows.Forms.ToolStripMenuItem()
        Me.Quit_ALL = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.Pony_Image, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RightClickMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pony_Image
        '
        Me.Pony_Image.Location = New System.Drawing.Point(0, 0)
        Me.Pony_Image.Name = "Pony_Image"
        Me.Pony_Image.Size = New System.Drawing.Size(0, 0)
        Me.Pony_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pony_Image.TabIndex = 0
        Me.Pony_Image.TabStop = False
        '
        'RightClickMenu
        '
        Me.RightClickMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddPonyMenu, Me.ToolStripSeparator2, Me.Sleep, Me.Sleep_All, Me.ToolStripSeparator3, Me.Take_Control_P1, Me.Take_Control_P2, Me.MenuSeparator, Me.Return_To_Menu, Me.Show_Options, Me.ToolStripSeparator1, Me.Quit, Me.Quit_ALL})
        Me.RightClickMenu.Name = "ContextMenuStrip1"
        Me.RightClickMenu.Size = New System.Drawing.Size(195, 226)
        '
        'AddPonyMenu
        '
        Me.AddPonyMenu.Name = "AddPonyMenu"
        Me.AddPonyMenu.Size = New System.Drawing.Size(194, 22)
        Me.AddPonyMenu.Text = "Add a pony->"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(191, 6)
        '
        'Sleep
        '
        Me.Sleep.Name = "Sleep"
        Me.Sleep.Size = New System.Drawing.Size(194, 22)
        Me.Sleep.Text = "Sleep/Pause"
        '
        'Sleep_All
        '
        Me.Sleep_All.Name = "Sleep_All"
        Me.Sleep_All.Size = New System.Drawing.Size(194, 22)
        Me.Sleep_All.Text = "Sleep/Pause All"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(191, 6)
        '
        'Take_Control_P1
        '
        Me.Take_Control_P1.Name = "Take_Control_P1"
        Me.Take_Control_P1.Size = New System.Drawing.Size(194, 22)
        Me.Take_Control_P1.Text = "Take Control - Player 1"
        '
        'Take_Control_P2
        '
        Me.Take_Control_P2.Name = "Take_Control_P2"
        Me.Take_Control_P2.Size = New System.Drawing.Size(194, 22)
        Me.Take_Control_P2.Text = "Take Control - Player 2"
        '
        'MenuSeparator
        '
        Me.MenuSeparator.Name = "MenuSeparator"
        Me.MenuSeparator.Size = New System.Drawing.Size(191, 6)
        '
        'Return_To_Menu
        '
        Me.Return_To_Menu.Name = "Return_To_Menu"
        Me.Return_To_Menu.Size = New System.Drawing.Size(194, 22)
        Me.Return_To_Menu.Text = "Return to Menu"
        '
        'Show_Options
        '
        Me.Show_Options.Name = "Show_Options"
        Me.Show_Options.Size = New System.Drawing.Size(194, 22)
        Me.Show_Options.Text = "Show Options"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(191, 6)
        '
        'Quit
        '
        Me.Quit.Name = "Quit"
        Me.Quit.Size = New System.Drawing.Size(194, 22)
        Me.Quit.Text = "Quit"
        '
        'Quit_ALL
        '
        Me.Quit_ALL.Name = "Quit_ALL"
        Me.Quit_ALL.Size = New System.Drawing.Size(194, 22)
        Me.Quit_ALL.Text = "Quit ALL"
        '
        'Pony_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.Disable
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(0, 0)
        Me.ControlBox = False
        Me.Controls.Add(Me.Pony_Image)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Pony_Form"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Pony_Form"
        Me.TopMost = True
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        CType(Me.Pony_Image, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RightClickMenu.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pony_Image As System.Windows.Forms.PictureBox
    Friend WithEvents RightClickMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Quit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Quit_ALL As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Take_Control_P1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Show_Options As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Sleep_All As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Sleep As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AddPonyMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Return_To_Menu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Take_Control_P2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
End Class
