﻿Public Class Filters_Form

    Private Sub Filters_Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Filters_Box.Clear()

        For Each category In My.Forms.Main.PonyFilter_Box.Items
            Filters_Box.AppendText(category & ControlChars.NewLine)
        Next

    End Sub


    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.Close()
    End Sub



    Private Sub Save_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Save_Button.Click

        My.Forms.Main.PonyFilter_Box.Items.Clear()

        For Each category In Filters_Box.Lines
            My.Forms.Main.PonyFilter_Box.Items.Add(category)
        Next

        Me.Close()

    End Sub
End Class