﻿
'IMPORTANT NOTE:  Transparancy is achieved by setting the transparancy key of the form, and the background color to the same shade of awful pink that hopefully no one uses.

Public Class Effect_Form

    'Functions needed for borderless window draging
    Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    Declare Function ReleaseCapture Lib "user32.dll" () As Boolean

    Friend End_time As DateTime
    Friend Follows As Boolean
    Friend direction As Pony.Directions
    Friend centering As Pony.Directions
    Friend effect_name As String
    Friend Close_On_New_Behavior As Boolean
    Friend Behavior_Name As String


    'don't steal focus when first shown.
    Protected Overrides ReadOnly Property ShowWithoutActivation() As Boolean

        Get

            Return True

        End Get

    End Property

    Friend Function Center() As Point

        Return New Point(Me.Location.X + (Effect_Image.Image.Size.Width / 2), Me.Location.Y + (Effect_Image.Image.Size.Height / 2))

    End Function

    Private Sub Effect_Drag(ByVal Sender As Object, ByVal e As MouseEventArgs) Handles Effect_Image.MouseDown

        If My.Forms.Options.Pony_Dragging_Enabled.Checked = False Then Exit Sub

        Try

            If e.Button = Windows.Forms.MouseButtons.Left Then
                ReleaseCapture()
                SendMessage(Me.Handle, 161, 2, 0)
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try

    End Sub

End Class