﻿'Did you think that this program handled all the graphics itself?  Sorry, no, each pony if just a regular form with a picturebox.


'IMPORTANT NOTE:  Transparancy is achieved by setting the transparancy key of the form, and the background color to the same shade of awful pink that hopefully no one uses.


Public Class Pony_Form

    'Functions needed for borderless window draging
    Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    Declare Function ReleaseCapture Lib "user32.dll" () As Boolean

    Dim PonyName = ""
    Friend My_Little_Pony As Pony = Nothing

    Friend Precise_X_Location As Double
    Friend Precise_Y_Location As Double

    'this is just a pointer so we can determine what image is being used
    'the actual image is cloned to prevent issues with repeating gifs
    Friend CurrentImage As Image = Nothing

    Friend ManualControl_P1 = False
    Friend ManualControl_P2 = False

    Friend PonyDirection As Boolean = False

    Friend sleeping = False
    Friend should_be_sleeping = False

    Friend dragging = False
    'was the pony already sleeping before the dragging started?
    Friend sleeping_before_drag = False

    'all "speech" is handled through a tooltip.
    Friend WithEvents tooltip1 As New ToolTip

    'User has the option of limiting songs to one-total at a time, or one-per-pony at a time.
    'thess two options are used for the one-per-pony option.
    Dim Audio_Last_Played As Date = Now()
    Dim Last_Audio_Length As Integer = 0

    Dim LastSpoke As DateTime = Now()

    Dim Audio_Error_Shown As Boolean = False

    Dim Lines_Random As New List(Of Pony.Behavior.Speaking_Line)
    Dim Lines_Specific As New List(Of Pony.Behavior.Speaking_Line)

    Friend Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        tooltip1.ReshowDelay = 0

        If My.Forms.Options.Disable_Speech.Checked = True Then
            tooltip1.Active = False
        End If

    End Sub

    Friend Sub setup_addpony_menu()

        Dim selection_menu As ToolStripMenuItem = RightClickMenu.Items("AddPonyMenu")

        For Each Pony In My.Forms.Main.Selectable_Ponies
            selection_menu.DropDownItems.Add(Pony.Name)
        Next

        For Each item As ToolStripMenuItem In selection_menu.DropDownItems
            AddHandler item.Click, AddressOf AddPony_Selection
        Next

    End Sub

    Sub AddPony_Selection(ByVal sender As ToolStripMenuItem, ByVal e As System.EventArgs)

        Dim pony_to_add = sender.Text

        If pony_to_add = "Random Pony" Then
            Dim selection = Math.Round(Rnd() * (My.Forms.Main.Selectable_Ponies.Count - 1), 0)

            pony_to_add = My.Forms.Main.Selectable_Ponies(selection).Name

            If pony_to_add = "Random Pony" Then
                pony_to_add = My.Forms.Main.Selectable_Ponies(selection + 1).Name
            End If
        End If

        For Each Pony In My.Forms.Main.Selectable_Ponies
            If Pony.Name = pony_to_add Then
                Dim new_pony = Pony.Duplicate
                My.Forms.Main.Active_Ponies.Add(new_pony)
                For Each other_Pony In Main.Active_Ponies
                    'we need to set up interactions again to account for new ponies.
                    other_Pony.Initialize_Interactions()
                Next
                Exit For
            End If
        Next
    End Sub

    'This is necessary to prevent us from stealing focus when being shown for the first time.
    Protected Overrides ReadOnly Property ShowWithoutActivation() As Boolean

        Get
            Return True
        End Get

    End Property

    Private Sub PonyPicture_Drag(ByVal Sender As Object, ByVal e As MouseEventArgs) Handles Pony_Image.MouseDown

        If My.Forms.Options.Pony_Dragging_Enabled.Checked = False Then Exit Sub

        Try
            If e.Button = Windows.Forms.MouseButtons.Left Then

                My.Forms.Main.dragging = True

                'because we keep two different coordinates, the 'precision' and form locations,
                'when the timer is active and ponies are moving, we need to make them sleep when dragging.
                'otherwise the two coordinates will get out of sync and they won't move
                '
                'On the other hand, if the user used "Sleep All", then the timer isn't running, 
                'and this method won't work because nothing will be updating the locations.
                'instead, we use a trick through the windows api.
                If Main.MoveTimer.Enabled = True Then
                    dragging = True
                    If sleeping = False Then
                        should_be_sleeping = True
                        sleeping_before_drag = False
                    Else
                        sleeping_before_drag = True
                    End If

                Else
                    ReleaseCapture()
                    SendMessage(Me.Handle, 161, 2, 0) 'sorry for the magic #s, but I got this from somewhere else that didn't explain them.
                End If
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try

    End Sub

    Friend Sub Pony_Picture_Drag_Release(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Pony_Image.MouseUp

        If e.Button = Windows.Forms.MouseButtons.Left Then
            If dragging Then
                dragging = False
                My.Forms.Main.Dragging = False
                If sleeping_before_drag = False Then
                    should_be_sleeping = False
                End If
            End If
        End If

    End Sub

    Private Sub Lost_Focus() Handles Me.Deactivate

        If dragging Then
            dragging = False
            My.Forms.Main.Dragging = False
            If sleeping_before_drag = False Then
                should_be_sleeping = False
            End If
        End If

    End Sub

    Friend Sub SetName(ByVal name As String, ByVal pony As Pony)
        PonyName = name
        My_Little_Pony = pony
    End Sub

    Friend Sub SetLines(ByVal speaking_lines As List(Of Pony.Behavior.Speaking_Line))

        Lines_Specific.Clear()
        Lines_Random.Clear()

        For Each line In speaking_lines

            If line.Skip = True Then
                Lines_Specific.Add(line)
            Else
                Lines_Random.Add(line)
            End If

        Next

        tooltip1.ShowAlways = True
    End Sub

    'The mouse is hovering over us.
    Private Sub Pony_Image_Hover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pony_Image.MouseHover

        Pony_Speak(Nothing)

    End Sub

    'User presses a key with us focused.
    Private Sub Pony_Key(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown, Me.KeyUp

        If My.Forms.Main.screen_saver_mode Then Main.Close()

        'If Not ManualControl_P1 AndAlso Not ManualControl_P2 Then
        '    Exit Sub
        'End If

        Dim keyboardinfo As New KeyboardInfo

        With My.Forms.Main
            If keyboardinfo.IsPressed(Keys.Down) Then
                .PonyDown = True
            Else
                .PonyDown = False
            End If
            If keyboardinfo.IsPressed(Keys.Up) Then
                .PonyUp = True
            Else
                .PonyUp = False
            End If

            If keyboardinfo.IsPressed(Keys.Right) Then
                .PonyRight = True
            Else
                .PonyRight = False
            End If
            If keyboardinfo.IsPressed(Keys.Left) Then
                .PonyLeft = True
            Else
                .PonyLeft = False
            End If

            If keyboardinfo.IsPressed(Keys.RShiftKey) Then
                .PonySpeed = True
            Else
                .PonySpeed = False
            End If

            If keyboardinfo.IsPressed(Keys.RControlKey) Then
                .PonyAction = True
            Else
                .PonyAction = False
            End If

            If keyboardinfo.IsPressed(Keys.S) Then
                .PonyDown_2 = True
            Else
                .PonyDown_2 = False
            End If
            If keyboardinfo.IsPressed(Keys.W) Then
                .PonyUp_2 = True
            Else
                .PonyUp_2 = False
            End If

            If keyboardinfo.IsPressed(Keys.D) Then
                .PonyRight_2 = True
            Else
                .PonyRight_2 = False
            End If
            If keyboardinfo.IsPressed(Keys.A) Then
                .PonyLeft_2 = True
            Else
                .PonyLeft_2 = False
            End If

            If keyboardinfo.IsPressed(Keys.LShiftKey) Then
                .PonySpeed_2 = True
            Else
                .PonySpeed_2 = False
            End If

            If keyboardinfo.IsPressed(Keys.LControlKey) Then
                .PonyAction_2 = True
            Else
                .PonyAction_2 = False
            End If
        End With

    End Sub

    Friend Sub Speech_Off()
        tooltip1.Active = False
    End Sub
    Friend Sub Speech_On()
        tooltip1.Active = True
    End Sub

    Friend Sub Pony_Speak(Optional ByVal line As Pony.Behavior.Speaking_Line = Nothing)

        'don't speak when someone's right click menu is active - it would steal focus and close the menu.
        If My.Forms.Main.Right_Click_Menu_Active = True Then Exit Sub
        If My.Forms.Main.dragging Then Exit Sub

        Dim selection = 0
        Dim line_to_speak As String = ""

        If Not IsNothing(line) Then
            line_to_speak = line.Text
            If line.SoundFile <> "" AndAlso Not My.Forms.Main.DisableSoundsDueToDirectXFailure Then
                Pony_PlaySound(line.SoundFile)
            End If
        Else
            If Lines_Random.Count = 0 Then
                Exit Sub
            Else
                selection = Math.Round(Rnd() * (Lines_Random.Count - 1), 0)
                line_to_speak = Lines_Random(selection).Text
                If Lines_Random(selection).SoundFile <> "" AndAlso Not My.Forms.Main.DisableSoundsDueToDirectXFailure Then
                    Pony_PlaySound(Lines_Random(selection).SoundFile)
                End If
            End If
        End If

        If My.Forms.Options.Disable_Speech.Checked = False Then

            Try
                'we can't activate the tooltip unless we have focus.
                Me.Focus()
                tooltip1.Show(PonyName & ": " & ControlChars.Quote & line_to_speak & ControlChars.Quote, Pony_Image, 0, 0, 3000)
            Catch ex As Exception
                'an exception may be thrown if the pony is being closed after a tooltip was made.
                'just ignore errors here.
            End Try
        End If

    End Sub

    Private Sub Pony_PlaySound(ByVal filename As String)


        If My.Computer.FileSystem.FileExists(filename) Then

            If My.Forms.Options.Sounds_Enabled.Checked = False Then Exit Sub

            If My.Forms.Main.screen_saver_mode AndAlso My.Forms.Options.ScreenSaver_Sounds_Checkbox.Checked = False Then
                Exit Sub
            End If

            'don't play sounds over other ones - wait until they finish.

            If My.Forms.Options.Sounds_Per_Pony_Radio.Checked Then
                If Now.Subtract(Me.Audio_Last_Played).TotalMilliseconds <= Me.Last_Audio_Length Then Exit Sub
            Else
                If Now.Subtract(My.Forms.Main.Audio_Last_Played).TotalMilliseconds <= My.Forms.Main.Last_Audio_Length Then Exit Sub
            End If

            Try

                'If you get a MDA warning about loader locking - you'll just have to disable that exception message.  
                'Apparently it is a bug with DirectX that only occurs with Visual Studio...
                'We use DirectX now so that we can use MP3 instead of WAV files
                Dim audio As New Microsoft.DirectX.AudioVideoPlayback.Audio(filename)

                My.Forms.Main.Active_Sounds.Add(audio)

                audio.Play()

                If My.Forms.Options.Sounds_Per_Pony_Radio.Checked Then
                    Me.Last_Audio_Length = audio.Duration * 1000
                    Me.Audio_Last_Played = Now()
                Else
                    My.Forms.Main.Last_Audio_Length = audio.Duration * 1000 'to milliseconds
                    My.Forms.Main.Audio_Last_Played = Now()
                End If

            Catch ex As Exception
                If Audio_Error_Shown = False AndAlso My.Forms.Main.screen_saver_mode = False Then
                    Audio_Error_Shown = True
                    MsgBox("Error playing sound " & filename & " for " & PonyName & ControlChars.NewLine _
                           & "Further sound errors will be suppressed." & ControlChars.NewLine & ex.Message)
                End If
            End Try

        End If
    End Sub

    Private Sub ContextMenu_ItemSelected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles RightClickMenu.ItemClicked

        Select Case e.ClickedItem.Name
            Case "Quit"
                Me.Close()
            Case "Quit_ALL"
                My.Forms.Main.Close()
            Case "Return_To_Menu"
                If My.Forms.Pony_Editor.Visible = True Then My.Forms.Pony_Editor.Close()
                My.Forms.Main.Pony_Shutdown()
                My.Forms.Main.Visible = True
                My.Forms.Main.Redraw_Menu()

            Case "Take_Control_P1"
                ManualControl_P1 = Not ManualControl_P1
                If My.Forms.Main.controlled_pony <> "" Then
                    My.Forms.Main.controlled_pony = PonyName
                Else
                    My.Forms.Main.controlled_pony = ""
                End If
                If Not ManualControl_P1 Then
                    RightClickMenu.Items("Take_Control_P1").Text = "Take Control - Player 1"
                Else
                    RightClickMenu.Items("Take_Control_P1").Text = "Release Control - Player 1"
                End If
            Case "Take_Control_P2"
                ManualControl_P2 = Not ManualControl_P2
                If My.Forms.Main.controlled_pony <> "" Then
                    My.Forms.Main.controlled_pony = PonyName
                Else
                    My.Forms.Main.controlled_pony = ""
                End If
                If Not ManualControl_P2 Then
                    RightClickMenu.Items("Take_Control_P2").Text = "Take Control - Player 2"
                Else
                    RightClickMenu.Items("Take_Control_P2").Text = "Release Control - Player 2"
                End If
            Case "Show_Options"
                If My.Forms.Main.Options_Is_Created Then
                    My.Forms.Options.Visible = True
                Else
                    My.Forms.Options.Show()
                    My.Forms.Main.Options_Is_Created = True
                End If
            Case "Sleep_All"
                My.Forms.Main.sleep_all()
            Case "Sleep"
                should_be_sleeping = Not should_be_sleeping
        End Select

        My.Forms.Main.Right_Click_Menu_Active = False

    End Sub

    Private Sub Pony_Image_Click(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Pony_Image.Click

        If My.Forms.Main.screen_saver_mode Then Main.Close()

        If e.Button = Windows.Forms.MouseButtons.Right Then

            My.Forms.Main.Right_Click_Menu_Active = True
            If should_be_sleeping Then
                RightClickMenu.Items("Sleep").Text = "Wake up/Resume"
            Else
                RightClickMenu.Items("Sleep").Text = "Sleep/Pause"
            End If

            If My.Forms.Main.MoveTimer.Enabled = False Then
                RightClickMenu.Items("Sleep_All").Text = "Wake up/Resume All"
            Else
                RightClickMenu.Items("Sleep_All").Text = "Sleep/Pause All"
            End If
            RightClickMenu.Show(Me.Location)
        End If

    End Sub


    Friend Function Center() As Point

        Dim image_center As Point = My_Little_Pony.GetImageCenter()

        If image_center = New Point Then
            Dim scale = My_Little_Pony.GetScale
            image_center = New Point((scale * (Pony_Image.Size.Width) / 2), (scale * (Pony_Image.Size.Height) / 2))
        End If

        Return New Point(Me.Location.X + image_center.X, Me.Location.Y + image_center.Y)


    End Function

    'We don't use me.location here as we may be testing another location! (the next or current one)
    Friend Function MouseOverCenters(ByVal testing_point As Point) As List(Of Point)

        Dim points As New List(Of Point)

        Dim scale = My_Little_Pony.GetScale

        For Each behavior In My_Little_Pony.Behaviors
            If behavior.Allowed_Movement = Pony.Allowed_Moves.MouseOver Then
                If Right AndAlso behavior.right_image_center <> New Point() Then
                    points.Add(New Point(testing_point.X + (scale * (behavior.right_image_center.X)), testing_point.Y + (scale * (behavior.right_image_center.Y))))
                Else
                    points.Add(New Point(testing_point.X + (scale * (My_Little_Pony.Behaviors(0).right_image.Size.Width)) / 2, _
                      testing_point.Y + (scale * (My_Little_Pony.Behaviors(0).right_image.Size.Height)) / 2))
                End If

                If Not Right AndAlso behavior.left_image_center <> New Point() Then
                    points.Add(New Point(testing_point.X + (scale * (behavior.left_image_center.X)), testing_point.Y + (scale * (behavior.left_image_center.Y))))
                Else
                    points.Add(New Point(testing_point.X + (scale * (My_Little_Pony.Behaviors(0).left_image.Size.Width)) / 2, _
                          testing_point.Y + (scale * (My_Little_Pony.Behaviors(0).left_image.Size.Height)) / 2))
                End If
            End If
        Next

        Return points


    End Function

    Private Sub Menu_close() Handles RightClickMenu.Closed
        My.Forms.Main.Right_Click_Menu_Active = False
    End Sub

    'fix a crash if a tooltip was active and the form was closed before the tooltip expired...
    '(the tooltip needs the image handle for some reason, and throws an exception if it is nothing when it is closing)
    Private Sub Closing_Cleanup() Handles Me.FormClosing
        Me.tooltip1.RemoveAll()
        Me.tooltip1.Hide(Pony_Image)
        Me.tooltip1.Active = False
    End Sub

End Class


